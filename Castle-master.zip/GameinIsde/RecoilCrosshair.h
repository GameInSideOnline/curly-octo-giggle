#pragma once

#include "draw.h"

namespace Recoilcrosshair
{
	void Paint();
};