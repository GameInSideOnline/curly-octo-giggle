#pragma once

namespace NoSky
{
	void FrameStageNotify(ClientFrameStage_t stage);
}