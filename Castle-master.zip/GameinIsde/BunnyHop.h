#pragma once

namespace BHop
{
	void CreateMove(CUserCmd* cmd);
}