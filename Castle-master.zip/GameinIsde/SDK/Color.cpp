#include "Color.h"
Color Red = Color(255, 0, 0, 255);
Color Green = Color(0, 255, 0, 255);
Color White = Color(255, 255, 255, 255);
Color Black = Color(10, 10, 10, 190);
Color T = Color(170, 10, 30, 255);
Color CT = Color(10, 170, 30, 255);