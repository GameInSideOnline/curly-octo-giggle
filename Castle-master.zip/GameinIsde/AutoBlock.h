#pragma once

namespace Autoblock
{
	void CreateMove(CUserCmd* cmd);
}