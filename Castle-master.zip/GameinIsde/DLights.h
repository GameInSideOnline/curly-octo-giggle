#pragma once

namespace Dlights
{
	void Paint();
}