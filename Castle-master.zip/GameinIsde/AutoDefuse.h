#pragma once

namespace AutoDefuse
{
	void CreateMove(CUserCmd* cmd);
};