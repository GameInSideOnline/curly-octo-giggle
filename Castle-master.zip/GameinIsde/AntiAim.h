#pragma once

namespace AntiAim
{
	bool GetBestHeadAngle(Vector& angle);
	void CreateMove(CUserCmd* cmd);
}