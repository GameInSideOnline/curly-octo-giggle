#pragma once
#include "ImGui\imgui.h"
#include "Interfaces.h"
#include "Renderer.h"

void Menu();
namespace Walk
{
	extern bool showWindow;

	extern void RenderWindow();
}