#pragma once

namespace JumpThrow
{
	void CreateMove(CUserCmd* cmd);
}