#pragma once
#include <climits>

namespace Airstuck
{
	void CreateMove(CUserCmd* cmd);
}