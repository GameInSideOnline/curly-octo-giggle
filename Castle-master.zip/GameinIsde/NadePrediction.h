#pragma once
void NadePrediction();