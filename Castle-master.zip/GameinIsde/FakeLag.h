#pragma once

#include "util.h"

namespace FakeLag
{
	void CreateMove(CUserCmd* cmd);
};