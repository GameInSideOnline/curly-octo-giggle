#pragma once

namespace Prediction
{
	void Start(CUserCmd* cmd);
	void End();
}