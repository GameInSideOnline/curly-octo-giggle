#pragma once
#include <Windows.h>
#include <ctime>
#include <chrono>
#include <thread>
#include <iostream>
#include "Vitalflea.h"
#include "Interfaces.h"
#include "SDK\NetvarManager.h"
#include "FindPattern.h"
#include "Hooks.h"

clock_t Timer;
