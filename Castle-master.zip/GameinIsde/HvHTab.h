#pragma once

namespace HvH
{
	void RenderTab();
}