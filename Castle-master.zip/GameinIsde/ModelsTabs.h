#pragma once

namespace Models
{
	void RenderTab();
}