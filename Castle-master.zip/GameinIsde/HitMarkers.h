#pragma once
namespace Hitmarkers
{
	void Paint();
	void FireGameEvent(IGameEvent* event);
}