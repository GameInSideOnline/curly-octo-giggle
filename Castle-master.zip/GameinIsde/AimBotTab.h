#pragma once

namespace Aimbot
{
	void RenderTab();
}
namespace UI
{
	void UpdateWeaponSettings();
	void ReloadWeaponSettings();
}