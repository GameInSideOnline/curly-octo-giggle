#pragma once


//Feature Pointers

namespace AutoAccept
{
	void PlaySound(const char* filename);
}

extern IsReady IsReadyCallback;
