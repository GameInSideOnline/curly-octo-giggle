#pragma once

namespace CustomGlow
{
	void FrameStageNotify(ClientFrameStage_t stage);
}