#pragma once
void FakeWalk(CUserCmd* cmd, bool& packet);