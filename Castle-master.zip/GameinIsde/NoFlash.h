#pragma once

namespace Noflash
{
	void FrameStageNotify(ClientFrameStage_t stage);
}