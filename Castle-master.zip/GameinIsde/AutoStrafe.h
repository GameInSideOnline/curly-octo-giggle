#pragma once

namespace AutoStrafe
{
	void CreateMove(CUserCmd* cmd);
}