#pragma once
extern bool Open;
void OpenConsole();