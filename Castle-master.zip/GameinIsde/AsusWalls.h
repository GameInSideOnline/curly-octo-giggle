#pragma once

namespace ASUSWalls
{
	void FrameStageNotify(ClientFrameStage_t stage);
}